//
//  Constant.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 29/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

let APP_URL: String = "http://www.google.com"
let EMAIL: String = "theihartfirm@gmail.com"

let FILEPATH_DOCUMENTS = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]

let IS_IPHONE: Bool = (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.phone)
let IS_RETINA: Bool = UIScreen.main.scale >= 2.0

let SCREEN_HEIGHT: CGFloat = UIScreen.main.bounds.size.height
let SCREEN_WIDTH: CGFloat = UIScreen.main.bounds.size.width

let SCREEN_MAX_LENGTH: CGFloat = max(SCREEN_WIDTH, SCREEN_HEIGHT)
let SCREEN_MIN_LENGTH: CGFloat = min(SCREEN_WIDTH, SCREEN_HEIGHT)

let IS_IPHONE_4_OR_LESS: Bool = (IS_IPHONE && SCREEN_MAX_LENGTH < 568.0)
let IS_IPHONE_5: Bool = (IS_IPHONE && SCREEN_MAX_LENGTH == 568.0)
let IS_IPHONE_6: Bool = (IS_IPHONE && SCREEN_MAX_LENGTH == 667.0)
let IS_IPHONE_6P: Bool = (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)
