//
//  Utility.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 29/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class Utility: NSObject
{

    class func getPath(fileName: String) -> String
    {
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fileURL = URL(string: "\(documentsURL)\(fileName)")
        
        print(fileURL!.path)
        
        return fileURL!.path
    }
    
    static func validateEmail(_ strInput: String) -> Bool
    {
        let emailRegex: String = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        let emailTest: NSPredicate = NSPredicate(format: "SELF MATCHES %@", argumentArray: [emailRegex])
        return emailTest.evaluate(with: strInput)
    }
    
    class func copyFile(fileName: NSString)
    {
        let dbPath: String = getPath(fileName: fileName as String)
        let fileManager = FileManager.default
        if !fileManager.fileExists(atPath: dbPath) {
            
            let documentsURL = Bundle.main.resourceURL
            let fromPath = URL(string: "\(documentsURL!)\(fileName)")
            
            var error : NSError?
            do {
                try fileManager.copyItem(atPath: fromPath!.path, toPath: dbPath)
            } catch let error1 as NSError {
                error = error1
            }
            
            if (error != nil) {
                print("db error : \(error?.localizedDescription)")
            } else {
                print("Your database copy successfully")
            }
        }
    }
    
    static func showAlertController(withTitle: String, withMessage: String, isOkButton: Bool, isCancelButton: Bool) -> UIAlertController
    {
        let alertController = UIAlertController(title: withTitle, message: withMessage, preferredStyle: .alert)
        
        if isCancelButton {
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
                
            }
            alertController.addAction(cancelAction)
        }
        
        if isOkButton {
            let OKAction = UIAlertAction(title: "Okay", style: .default) { (action:UIAlertAction!) in
                
            }
            alertController.addAction(OKAction)
        }
        
        return alertController
    }
    
}
