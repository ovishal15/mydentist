//
//  DBManager.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 29/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

let sharedInstance = DBManager()

class DBManager: NSObject
{
    
    var database: FMDatabase? = nil
    
    class func getInstance() -> DBManager
    {
        if sharedInstance.database == nil {
            sharedInstance.database = FMDatabase(path: Utility.getPath(fileName: "MyDentist.sqlite"))
        }
        
        return sharedInstance
    }
    
    func isUserLoginSuccessful(withEmail email: String, withPassword pwd: String, withType type: Int) -> (Bool, String)
    {
        sharedInstance.database!.open()
        var resultSet: FMResultSet!
        
        if type == 0 {
            
            resultSet = sharedInstance.database!.executeQuery("SELECT * FROM doctor WHERE email = ? AND password = ?", withArgumentsIn: [email, pwd])
        } else if type == 1 {
            
            resultSet = sharedInstance.database!.executeQuery("SELECT * FROM patient WHERE email = ? AND password = ?", withArgumentsIn: [email, pwd])
        } else if type == 2 {
            
            resultSet = sharedInstance.database!.executeQuery("SELECT * FROM lab WHERE email = ? AND password = ?", withArgumentsIn: [email, pwd])
        } else {
            
            return (false, "")
        }
        
        var strID: String = ""
        var isAvailable: Bool = false
        if (resultSet != nil) {
            while resultSet.next() {
                
                strID = "\(resultSet.int(forColumn: "id"))"
                isAvailable = true
            }
        }
        
        sharedInstance.database!.close()
        
        return (isAvailable, strID)
    }
    
    func getUserDataByEmailAndPassword() -> UserModel
    {
        sharedInstance.database!.open()
        var resultSet: FMResultSet!
        
        let email = "\(UserDefaults.standard.value(forKey: "UserEmail")!)"
        let pwd = "\(UserDefaults.standard.value(forKey: "UserPassword")!)"
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            resultSet = sharedInstance.database!.executeQuery("SELECT * FROM doctor WHERE email = ? AND password = ?", withArgumentsIn: [email, pwd])
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            resultSet = sharedInstance.database!.executeQuery("SELECT * FROM patient WHERE email = ? AND password = ?", withArgumentsIn: [email, pwd])
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            resultSet = sharedInstance.database!.executeQuery("SELECT * FROM lab WHERE email = ? AND password = ?", withArgumentsIn: [email, pwd])
        }
        
        let objModel: UserModel = UserModel()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strEmail = resultSet.string(forColumn: "email")
                objModel.strPassword = resultSet.string(forColumn: "password")
                objModel.strAddress = resultSet.string(forColumn: "address")
                objModel.strContact = resultSet.string(forColumn: "contact")
                
                if UserDefaults.standard.bool(forKey: "isPatient") {
                    
                    objModel.strAge = resultSet.string(forColumn: "age")
                }
            }
        }
        
        sharedInstance.database!.close()
        
        return objModel
    }
    
    func insertPatient(objModel: UserModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isInsertPayLoad: Bool = sharedInstance.database!.executeUpdate("INSERT INTO patient (name, email, password, address, contact, age) VALUES (?, ?, ?, ?, ?, ?)", withArgumentsIn: [objModel.strName, objModel.strEmail, objModel.strPassword, objModel.strAddress, objModel.strContact, objModel.strAge])
        
        sharedInstance.database!.close()
        
        return isInsertPayLoad
    }
    
    func updatePatient(objModel: UserModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isUpdatePayLoad: Bool = sharedInstance.database!.executeUpdate("UPDATE patient SET name = ?, address = ?, contact = ?, age = ? WHERE id = ?", withArgumentsIn: [objModel.strName, objModel.strAddress, objModel.strContact, objModel.strAge, objModel.strID])
        
        sharedInstance.database!.close()
        
        return isUpdatePayLoad
    }
    
    func getPatientByPatientID(strID: String) -> UserModel
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM patient WHERE id = ?", withArgumentsIn: [strID])
        
        let objModel: UserModel = UserModel()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strEmail = resultSet.string(forColumn: "email")
                objModel.strAddress = resultSet.string(forColumn: "address")
                objModel.strContact = resultSet.string(forColumn: "contact")
                objModel.strAge = resultSet.string(forColumn: "age")
            }
        }
        
        sharedInstance.database!.close()
        
        return objModel
    }
    
    func isEmailAddressAvailable(email: String) -> Bool
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM patient, doctor, lab WHERE patient.email = ? OR doctor.email = ? OR lab.email = ?", withArgumentsIn: [email, email, email])
        
        var isAvailable: Bool = true
        if (resultSet != nil) {
            while resultSet.next() {
                
                isAvailable = false
            }
        }
        
        sharedInstance.database!.close()
        
        return isAvailable
    }
    
    func insertDoctor(objModel: UserModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isInsertPayLoad: Bool = sharedInstance.database!.executeUpdate("INSERT INTO doctor (name, email, password, address, contact) VALUES (?, ?, ?, ?, ?)", withArgumentsIn: [objModel.strName, objModel.strEmail, objModel.strPassword, objModel.strAddress, objModel.strContact])
        
        sharedInstance.database!.close()
        
        return isInsertPayLoad
    }
    
    func updateDoctor(objModel: UserModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isUpdatePayLoad: Bool = sharedInstance.database!.executeUpdate("UPDATE doctor SET name = ?, address = ?, contact = ? WHERE id = ?", withArgumentsIn: [objModel.strName, objModel.strAddress, objModel.strContact, objModel.strID])
        
        sharedInstance.database!.close()
        
        return isUpdatePayLoad
    }
    
    func getDoctorByDoctorID(strID: String) -> UserModel
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM doctor WHERE id = ?", withArgumentsIn: [strID])
        
        let objModel: UserModel = UserModel()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strEmail = resultSet.string(forColumn: "email")
                objModel.strAddress = resultSet.string(forColumn: "address")
                objModel.strContact = resultSet.string(forColumn: "contact")
            }
        }
        
        sharedInstance.database!.close()
        
        return objModel
    }
    
    func getLabUserByLabID(strID: String) -> UserModel
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM lab WHERE id = ?", withArgumentsIn: [strID])
        
        let objModel: UserModel = UserModel()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strEmail = resultSet.string(forColumn: "email")
                objModel.strAddress = resultSet.string(forColumn: "address")
                objModel.strContact = resultSet.string(forColumn: "contact")
            }
        }
        
        sharedInstance.database!.close()
        
        return objModel
    }
    
    func insertLab(objModel: UserModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isInsertPayLoad: Bool = sharedInstance.database!.executeUpdate("INSERT INTO lab (name, email, password, address, contact, lat, log) VALUES (?, ?, ?, ?, ?, ?, ?)", withArgumentsIn: [objModel.strName, objModel.strEmail, objModel.strPassword, objModel.strAddress, objModel.strContact, objModel.strLat, objModel.strLog])
        
        sharedInstance.database!.close()
        
        return isInsertPayLoad
    }
    
    func updateLab(objModel: UserModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isUpdatePayLoad: Bool = sharedInstance.database!.executeUpdate("UPDATE lab SET name = ?, address = ?, contact = ? WHERE id = ?", withArgumentsIn: [objModel.strName, objModel.strAddress, objModel.strContact, objModel.strID])
        
        sharedInstance.database!.close()
        
        return isUpdatePayLoad
    }
    
    func insertAppointment(objModel: AppointmentModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isInsertPayLoad: Bool = sharedInstance.database!.executeUpdate("INSERT INTO appointment (doctor_id, patient_id, date, problem, note, name, status) VALUES (?, ?, ?, ?, ?, ?, ?)", withArgumentsIn: [objModel.strDoctorID, objModel.strPatientID, objModel.strDate, objModel.strProblem, objModel.strNote, objModel.strName, objModel.strStatus])
        
        sharedInstance.database!.close()
        
        return isInsertPayLoad
    }
    
    func deleteAppointment(objModel: AppointmentModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isDeletePayLoad: Bool = sharedInstance.database!.executeUpdate("DELETE FROM appointment WHERE id = ?", withArgumentsIn: [objModel.strID])
        
        sharedInstance.database!.close()
        
        return isDeletePayLoad
    }
    
    func selectAllAppointmentByUser() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM appointment WHERE patient_id = ? ORDER BY id DESC", withArgumentsIn: ["\(UserDefaults.standard.value(forKey: "UserID")!)"])
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: AppointmentModel = AppointmentModel()
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strDoctorID = resultSet.string(forColumn: "doctor_id")
                objModel.strPatientID = resultSet.string(forColumn: "patient_id")
                objModel.strDate = resultSet.string(forColumn: "date")
                objModel.strProblem = resultSet.string(forColumn: "problem")
                objModel.strNote = resultSet.string(forColumn: "note")
                objModel.strStatus = resultSet.string(forColumn: "status")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func selectAllLabBookingByUser() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM labbook WHERE doctor_id = ? ORDER BY id DESC", withArgumentsIn: ["\(UserDefaults.standard.value(forKey: "UserID")!)"])
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: LabBookModel = LabBookModel()
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strDoctorID = resultSet.string(forColumn: "doctor_id")
                objModel.strLabID = resultSet.string(forColumn: "lab_id")
                objModel.strDate = resultSet.string(forColumn: "date")
                objModel.strStatus = resultSet.string(forColumn: "status")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func selectAllAppointmentListByStatus(withStatus status: String) -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM appointment WHERE doctor_id = ? AND status = ? ORDER BY id DESC", withArgumentsIn: ["\(UserDefaults.standard.value(forKey: "UserID")!)", status]) 
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: AppointmentModel = AppointmentModel()
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strDoctorID = resultSet.string(forColumn: "doctor_id")
                objModel.strPatientID = resultSet.string(forColumn: "patient_id")
                objModel.strDate = resultSet.string(forColumn: "date")
                objModel.strProblem = resultSet.string(forColumn: "problem")
                objModel.strNote = resultSet.string(forColumn: "note")
                objModel.strStatus = resultSet.string(forColumn: "status")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func selectAllBookingListByStatus(withStatus status: String) -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM labbook WHERE lab_id = ? AND status = ? ORDER BY id DESC", withArgumentsIn: ["\(UserDefaults.standard.value(forKey: "UserID")!)", status])
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: LabBookModel = LabBookModel()
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strDoctorID = resultSet.string(forColumn: "doctor_id")
                objModel.strLabID = resultSet.string(forColumn: "lab_id")
                objModel.strDate = resultSet.string(forColumn: "date")
                objModel.strStatus = resultSet.string(forColumn: "status")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func selectAllReportListByStatus(withStatus status: String) -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM report WHERE lab_id = ? AND status = ? ORDER BY id DESC", withArgumentsIn: ["\(UserDefaults.standard.value(forKey: "UserID")!)", status])
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: ReportModel = ReportModel()
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strLabID = resultSet.string(forColumn: "lab_id")
                objModel.strWorkType = resultSet.string(forColumn: "work_type")
                objModel.strIsTrial = resultSet.string(forColumn: "isTrial")
                objModel.strDate = resultSet.string(forColumn: "date")
                objModel.strIsUrgent = resultSet.string(forColumn: "isUrgent")
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strRemark = resultSet.string(forColumn: "remark")
                objModel.strStatus = resultSet.string(forColumn: "status")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func selectAllDoctor() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM doctor", withArgumentsIn: [])
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: UserModel = UserModel()
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strEmail = resultSet.string(forColumn: "email")
                objModel.strAddress = resultSet.string(forColumn: "address")
                objModel.strContact = resultSet.string(forColumn: "contact")
                objModel.strLat = resultSet.string(forColumn: "lat")
                objModel.strLog = resultSet.string(forColumn: "log")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func selectAllReport() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM report", withArgumentsIn: [])
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: ReportModel = ReportModel()
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strLabID = resultSet.string(forColumn: "lab_id")
                objModel.strWorkType = resultSet.string(forColumn: "work_type")
                objModel.strIsTrial = resultSet.string(forColumn: "isTrial")
                objModel.strDate = resultSet.string(forColumn: "date")
                objModel.strIsUrgent = resultSet.string(forColumn: "isUrgent")
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strRemark = resultSet.string(forColumn: "remark")
                objModel.strStatus = resultSet.string(forColumn: "status")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func selectAllLab() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM lab", withArgumentsIn: [])
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: UserModel = UserModel()
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strName = resultSet.string(forColumn: "name")
                objModel.strEmail = resultSet.string(forColumn: "email")
                objModel.strAddress = resultSet.string(forColumn: "address")
                objModel.strContact = resultSet.string(forColumn: "contact")
                objModel.strLat = resultSet.string(forColumn: "lat")
                objModel.strLog = resultSet.string(forColumn: "log")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func updateStatusOfAppointment(strID: String, withStatus status: String) -> Bool
    {
        sharedInstance.database!.open()
        
        let isUpdatePayLoad: Bool = sharedInstance.database!.executeUpdate("UPDATE appointment SET status = ? WHERE id = ?", withArgumentsIn: [status, strID])
        
        sharedInstance.database!.close()
        
        return isUpdatePayLoad
    }
    
    func updateStatusOfBooking(strID: String, withStatus status: String) -> Bool
    {
        sharedInstance.database!.open()
        
        let isUpdatePayLoad: Bool = sharedInstance.database!.executeUpdate("UPDATE labbook SET status = ? WHERE id = ?", withArgumentsIn: [status, strID])
        
        sharedInstance.database!.close()
        
        return isUpdatePayLoad
    }
    
    func updateStatusOfReportAccept(strID: String, withStatus status: String) -> Bool
    {
        sharedInstance.database!.open()
        
        let isUpdatePayLoad: Bool = sharedInstance.database!.executeUpdate("UPDATE report SET status = ? WHERE id = ?", withArgumentsIn: [status, strID])
        
        sharedInstance.database!.close()
        
        return isUpdatePayLoad
    }
    
    func updateDateOfAppointmnetWithID(strID: String, withDate date: String) -> Bool
    {
        sharedInstance.database!.open()
        
        let isUpdatePayLoad: Bool = sharedInstance.database!.executeUpdate("UPDATE appointment SET date = ? WHERE id = ?", withArgumentsIn: [date, strID])
        
        sharedInstance.database!.close()
        
        return isUpdatePayLoad
    }
    
    func insertLabBook(objModel: LabBookModel) -> Bool
    {
        if self.isAlreadyBookedLab(objModel: objModel) {
            
            sharedInstance.database!.open()
            
            let isUpdatePayLoad: Bool = sharedInstance.database!.executeUpdate("UPDATE labbook SET date = ? WHERE doctor_id = ? AND lab_id = ?", withArgumentsIn: [objModel.strDate, objModel.strDoctorID, objModel.strLabID])
            
            sharedInstance.database!.close()
            
            return isUpdatePayLoad
        } else {
            
            sharedInstance.database!.open()
            
            let isInsertPayLoad: Bool = sharedInstance.database!.executeUpdate("INSERT INTO labbook (doctor_id, lab_id, date, status) VALUES (?, ?, ?, ?)", withArgumentsIn: [objModel.strDoctorID, objModel.strLabID, objModel.strDate, objModel.strStatus])
            
            sharedInstance.database!.close()
            
            return isInsertPayLoad
        }
    }
    
    func isAlreadyBookedLab(objModel: LabBookModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM labbook WHERE doctor_id = ? AND lab_id = ?", withArgumentsIn: [objModel.strDoctorID, objModel.strLabID])
        
        var isAvailable: Bool = false
        if (resultSet != nil) {
            while resultSet.next() {
                
                let strDate: String = resultSet.string(forColumn: "date")
                let extractDate: String = strDate.substring(to: 10)
                if objModel.strDate.contains(extractDate) {
                    
                    isAvailable = true
                } else {
                    
                    isAvailable = false
                }
            }
        }
        
        sharedInstance.database!.close()
        
        return isAvailable
    }
    
    func selectAllLabWithAvailable() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM labbook WHERE status = 'Accepted'", withArgumentsIn: [])
        
        let marrData: NSMutableArray = NSMutableArray()
        
        if (resultSet != nil) {
            while resultSet.next() {
                
                let objModel: LabBookModel = LabBookModel()
                
                objModel.strID = "\(resultSet.int(forColumn: "id"))"
                objModel.strDoctorID = resultSet.string(forColumn: "doctor_id")
                objModel.strLabID = resultSet.string(forColumn: "lab_id")
                objModel.strDate = resultSet.string(forColumn: "date")
                objModel.strStatus = resultSet.string(forColumn: "status")
                
                marrData.add(objModel)
            }
        }
        
        sharedInstance.database!.close()
        
        return marrData
    }
    
    func insertReportForLab(objModel: ReportModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isInsertPayLoad: Bool = sharedInstance.database!.executeUpdate("INSERT INTO report (lab_id, work_type, isTrial, date, isUrgent, name, remark, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", withArgumentsIn: [objModel.strLabID, objModel.strWorkType, objModel.strIsTrial, objModel.strDate, objModel.strIsUrgent, objModel.strName, objModel.strRemark, objModel.strStatus])
        
        sharedInstance.database!.close()
        
        return isInsertPayLoad
    }
    
    func deleteReport(objModel: ReportModel) -> Bool
    {
        sharedInstance.database!.open()
        
        let isDeletePayLoad: Bool = sharedInstance.database!.executeUpdate("DELETE FROM report WHERE id = ?", withArgumentsIn: [objModel.strID])
        
        sharedInstance.database!.close()
        
        return isDeletePayLoad
    }
    
}

extension String {
    func index(from: Int) -> Index {
        return self.index(startIndex, offsetBy: from)
    }
    
    func substring(from: Int) -> String {
        let fromIndex = index(from: from)
        return substring(from: fromIndex)
    }
    
    func substring(to: Int) -> String {
        let toIndex = index(from: to)
        return substring(to: toIndex)
    }
    
    func substring(with r: Range<Int>) -> String {
        let startIndex = index(from: r.lowerBound)
        let endIndex = index(from: r.upperBound)
        return substring(with: startIndex..<endIndex)
    }
}
