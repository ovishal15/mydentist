//
//  AppointmentModel.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 29/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class AppointmentModel: NSObject
{
    var strID: String = ""
    var strName: String = ""
    var strDoctorID: String = ""
    var strPatientID: String = ""
    var strDate: String = ""
    var strProblem: String = ""
    var strNote: String = ""
    var strStatus: String = ""
}
