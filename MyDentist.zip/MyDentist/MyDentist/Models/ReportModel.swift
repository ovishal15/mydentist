//
//  ReportModel.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 03/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class ReportModel: NSObject
{
    var strID: String = ""
    var strLabID: String = ""
    var strWorkType: String = ""
    var strIsTrial: String = ""
    var strDate: String = ""
    var strIsUrgent: String = ""
    var strName: String = ""
    var strRemark: String = ""
    var strStatus: String = ""
}
