//
//  UserModel.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 29/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class UserModel: NSObject
{
    var strID: String = ""
    var strName: String = ""
    var strEmail: String = ""
    var strPassword: String = ""
    var strAddress: String = ""
    var strContact: String = ""
    var strAge: String = ""
    var strLat: String = ""
    var strLog: String = ""
}
