//
//  LabBook.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 02/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class LabBookModel: NSObject
{
    var strID: String = ""
    var strDate: String = ""
    var strDoctorID: String = ""
    var strLabID: String = ""
    var strStatus: String = ""
}
