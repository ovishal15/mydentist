//
//  AppointmentTableViewCell.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 30/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class AppointmentTableViewCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblStaus: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblPatientContactNo: UILabel!
    @IBOutlet weak var lblPatientName: UILabel!
    @IBOutlet weak var btnReject: UIButton!
    @IBOutlet weak var btnAccept: UIButton!
    
    @IBOutlet weak var ivLogo: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
