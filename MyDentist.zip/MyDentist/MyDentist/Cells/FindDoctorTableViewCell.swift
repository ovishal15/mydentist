//
//  FindDoctorTableViewCell.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 31/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class FindDoctorTableViewCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var ivIcon: UIImageView!
    @IBOutlet weak var lblContactNo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
