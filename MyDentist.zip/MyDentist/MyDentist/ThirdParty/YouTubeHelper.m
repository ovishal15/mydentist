//
//  YouTubeHelper.m
//  MyDentist
//
//  Created by Hardik Trivedi on 02/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

#import "YouTubeHelper.h"

@implementation YouTubeHelper

    + (NSString *)getVideoIDFormYoutube:(NSString *)strLink
    {
        
        //Matches:
        //
        //    youtube.com/v/vidid
        //    youtube.com/vi/vidid
        //    youtube.com/?v=vidid
        //    youtube.com/?vi=vidid
        //    youtube.com/watch?v=vidid
        //    youtube.com/watch?vi=vidid
        //    youtu.be/vidid
        //    youtube.com/embed/vidid
        //http://youtube.com/v/vidid
        //http://www.youtube.com/v/vidid
        //https://www.youtube.com/v/vidid
        //    youtube.com/watch?v=vidid&wtv=wtv
        //http://www.youtube.com/watch?dev=inprogress&v=vidid&feature=related
        //https://m.youtube.com/watch?v=vidid
        //    Does not match:
        //
        //    www.facebook.com?wtv=youtube.com/v/vidid
        //https://www.facebook.com/video.php?v=10155279523025107
        
        
        NSString *regexString = @"^(?:http(?:s)?://)?(?:www\\.)?(?:m\\.)?(?:youtu\\.be/|youtube\\.com/(?:(?:watch)?\\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)/))([^\?&\"'>]+)";
        
        NSError *error;
        NSRegularExpression *regex =
        [NSRegularExpression regularExpressionWithPattern:regexString
                                                  options:NSRegularExpressionCaseInsensitive
                                                    error:&error];
        NSTextCheckingResult *match = [regex firstMatchInString:strLink
                                                        options:0
                                                          range:NSMakeRange(0, [strLink length])];
        
        if (match && match.numberOfRanges == 2) {
            NSRange videoIDRange = [match rangeAtIndex:1];
            NSString *videoID = [strLink substringWithRange:videoIDRange];
            
            return videoID;
        } else {
            return @"";
        }
    }
    
@end
