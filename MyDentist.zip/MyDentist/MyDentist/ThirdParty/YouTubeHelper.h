//
//  YouTubeHelper.h
//  MyDentist
//
//  Created by Hardik Trivedi on 02/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YouTubeHelper : NSObject

    + (NSString *)getVideoIDFormYoutube:(NSString *)strLink;
    
@end
