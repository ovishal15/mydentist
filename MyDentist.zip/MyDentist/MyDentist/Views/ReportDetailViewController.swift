//
//  ReportDetailViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 03/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class ReportDetailViewController: UIViewController, UITextFieldDelegate
{
    
    var marrData: NSMutableArray = NSMutableArray()
    var selectedLab: Int = 0
    
    @IBOutlet weak var tblData: UITableView!
    @IBOutlet weak var vwReportForm: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtRemarks: UITextField!
    @IBOutlet weak var segmentWorkType: UISegmentedControl!
    @IBOutlet weak var btnSelectDate: UIButton!
    @IBOutlet weak var switchTrial: UISwitch!
    @IBOutlet weak var swiftchUrgent: UISwitch!
    @IBOutlet weak var vwDateTimeView: UIView!
    @IBOutlet weak var vwBG: UIView!
    @IBOutlet weak var datepickerBook: UIDatePicker!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        self.vwReportForm.isHidden = true
        self.fetchDataFromDB()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        
        return true
    }

    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCreateNowTapped(_ sender: Any)
    {
        let title: String = (txtTitle.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let remark: String = (txtRemarks.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        
        let objModel: ReportModel = ReportModel()
        let objLabModel: UserModel = self.marrData[selectedLab] as! UserModel
        
        if btnSelectDate.titleLabel?.text == "Select Delivery Date" {
            
            let alert = Utility.showAlertController(withTitle: "Requried", withMessage: "Please select delvivery date.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
            
            return
        }
        
        objModel.strLabID = objLabModel.strID
        objModel.strDate = (btnSelectDate.titleLabel?.text)!
        objModel.strName = title
        objModel.strRemark = remark
        objModel.strIsUrgent = (swiftchUrgent.isOn) ? "Yes" : "No"
        objModel.strIsTrial = (switchTrial.isOn) ? "Yes" : "No"
        objModel.strStatus = "Waiting"
        
        if segmentWorkType.selectedSegmentIndex == 0 {
            
            objModel.strWorkType = "Metal"
        } else if segmentWorkType.selectedSegmentIndex == 1 {
            
            objModel.strWorkType = "Ceramic"
        } else if segmentWorkType.selectedSegmentIndex == 2 {
            
            objModel.strWorkType = "Zirconia"
        }
        
        if DBManager.getInstance().insertReportForLab(objModel: objModel) {
            
            let alert = UIAlertController(title: "Success", message: "Your report created successfully.", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                
                _ = self.navigationController?.popViewController(animated: true)
            }))
            
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnDonePickertTapped(_ sender: Any)
    {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height
            self.vwBG.isHidden = true
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy hh:mm:ss"
        let selectedDate = dateFormatter.string(from: datepickerBook.date)
        
        btnSelectDate.setTitle(selectedDate, for: .normal)
    }
    
    @IBAction func btnSelectDateTapped(_ sender: Any)
    {
        txtTitle.resignFirstResponder()
        txtRemarks.resignFirstResponder()
        
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height - self.vwDateTimeView.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height - self.vwDateTimeView.frame.size.height
            self.vwBG.isHidden = false
        }
    }
    
    @IBAction func btnCancelPickerTapped(_ sender: Any)
    {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height
            self.vwBG.isHidden = true
        }
    }
    
    func fetchDataFromDB()
    {
        marrData = NSMutableArray()
        
        marrData = DBManager.getInstance().selectAllLab()
        
        if marrData.count > 0 {
            
            tblData.reloadData()
            tblData.isHidden = false
        } else {
            
            tblData.isHidden = true
        }
    }
    
}

extension ReportDetailViewController: UITableViewDelegate, UITableViewDataSource
{
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return marrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell: FindDoctorTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FindDoctorTableViewCell
        
        let objModel: UserModel = self.marrData[indexPath.row] as! UserModel
        
        cell.lblName.text = objModel.strName
        cell.lblContactNo.text = "\(objModel.strContact)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        
        selectedLab = indexPath.row
        
        vwReportForm.isHidden = false
        tblData.isHidden = true
        lblNoData.isHidden = true
    }
    
}
