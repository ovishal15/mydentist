//
//  DocDetailViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 31/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit
import MapKit

class DocDetailViewController: UIViewController, UITextFieldDelegate
{
    
    var objUserModel: UserModel = UserModel()
    
    @IBOutlet weak var vwBooking: UIView!
    @IBOutlet weak var mapDoctorLocation: MKMapView!
    @IBOutlet weak var btnBookApp: UIButton!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblContactNo: UILabel!
    @IBOutlet weak var txtProblem: UITextField!
    @IBOutlet weak var txtExtraInfo: UITextField!
    @IBOutlet weak var txtAppointmentTitle: UITextField!
    @IBOutlet weak var btnSelectDate: UIButton!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var vwDateTimeView: UIView!
    @IBOutlet weak var vwBG: UIView!
    @IBOutlet weak var datepickerBook: UIDatePicker!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.fillAllData()
        vwBooking.isHidden = true
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            self.navigationItem.title = "Lab Detail"
            self.btnBookApp.isHidden = true
            self.btnBookApp.setTitle("Book Lab", for: .normal)
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            self.navigationItem.title = "Doctor Detail"
            self.btnBookApp.isHidden = false
            self.btnBookApp.setTitle("Book Appointment", for: .normal)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        
        return true
    }
    
    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSelectDateTapped(_ sender: Any)
    {
        txtProblem.resignFirstResponder()
        txtExtraInfo.resignFirstResponder()
        txtAppointmentTitle.resignFirstResponder()
        
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height - self.vwDateTimeView.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height - self.vwDateTimeView.frame.size.height
            self.vwBG.isHidden = false
        }
    }
    
    @IBAction func btnCancelPickerTapped(_ sender: Any)
    {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height
            self.vwBG.isHidden = true
        }
    }
    
    @IBAction func btnDonePickerTapped(_ sender: Any)
    {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.view.frame.size.height
            self.vwBG.isHidden = true
        }
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy hh:mm:ss"
            let selectedDate = dateFormatter.string(from: datepickerBook.date)
            
            let alert = UIAlertController(title: "Lab Book", message: "\(selectedDate). Are you sure this lab will book for this date?", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "NO", style: .cancel, handler: { (action) in
                
            }))
            
            alert.addAction(UIAlertAction(title: "YES", style: .default, handler: { (action) in
                
                let objLabBookModel: LabBookModel = LabBookModel()
                
                objLabBookModel.strStatus = "Waiting"
                objLabBookModel.strDate = selectedDate
                objLabBookModel.strDoctorID = "\(UserDefaults.standard.value(forKey: "UserID")!)"
                objLabBookModel.strLabID = self.objUserModel.strID
                
                if DBManager.getInstance().insertLabBook(objModel: objLabBookModel) {
                    
                    let alert1 = Utility.showAlertController(withTitle: "Lab Book", withMessage: "You have successfully booked this Lab.", isOkButton: true, isCancelButton: false)
                    self.present(alert1, animated: true, completion: nil)
                }
            }))
            
            self.present(alert, animated: true, completion: nil)
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy hh:mm:ss"
            let selectedDate = dateFormatter.string(from: datepickerBook.date)
            
            btnSelectDate.setTitle(selectedDate, for: .normal)
        }
    }
    
    @IBAction func btnCancelBookTapped(_ sender: Any)
    {
        vwBooking.isHidden = true
    }
    
    @IBAction func btnBookTapped(_ sender: Any)
    {
        let name: String = (txtAppointmentTitle.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let problem: String = (txtProblem.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let note: String = (txtExtraInfo.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let date: String = (btnSelectDate.titleLabel!.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        
        if name == "" || date == "Select Date" {
            
            let alert = Utility.showAlertController(withTitle: "Requried Field", withMessage: "Please enter Title & Select appointment date for booking Doctor.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
            
            return
        }
        
        let objAppointment: AppointmentModel = AppointmentModel()
        
        objAppointment.strID = ""
        objAppointment.strName = name
        objAppointment.strProblem = problem
        objAppointment.strNote = note
        objAppointment.strDate = date
        objAppointment.strStatus = "Waiting"
        objAppointment.strDoctorID = objUserModel.strID
        objAppointment.strPatientID = "\(UserDefaults.standard.value(forKey: "UserID")!)"
        
        if DBManager.getInstance().insertAppointment(objModel: objAppointment) {
            
            let alert = UIAlertController(title: "Success", message: "Your appointment booked successfully.", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                
                self.vwBooking.isHidden = true
            }))
            
            self.present(alert, animated: true, completion: nil)
        } else {
            
            let alert = Utility.showAlertController(withTitle: "Error", withMessage: "Something went wrong. Please check your email & password.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnBookAppointmentTapped(_ sender: Any)
    {
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
                
                self.vwDateTimeView.frame.origin.y = self.view.frame.size.height - self.vwDateTimeView.frame.size.height
            }) { (isAnimated) in
                
                self.vwDateTimeView.frame.origin.y = self.view.frame.size.height - self.vwDateTimeView.frame.size.height
                self.vwBG.isHidden = false
            }
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            vwBooking.isHidden = false
            vwBG.isHidden = true
            
            txtProblem.text = ""
            txtExtraInfo.text = ""
            txtAppointmentTitle.text = ""
            btnSelectDate.setTitle("Select Date", for: .normal)
        }
    }
    
    func fillAllData()
    {
        lblName.text = objUserModel.strName
        lblAddress.text = objUserModel.strAddress
        lblContactNo.text = objUserModel.strContact
        lblEmail.text = objUserModel.strEmail
        
        if objUserModel.strLat == "" || objUserModel.strLog == ""  {
            
            mapDoctorLocation.isHidden = true
        } else {
            
            mapDoctorLocation.isHidden = false
            
            let annotation = MKPointAnnotation()
            annotation.title = objUserModel.strName
            annotation.coordinate = CLLocationCoordinate2D(latitude: CLLocationDegrees.init(objUserModel.strLat)!, longitude: CLLocationDegrees.init(objUserModel.strLog)!)
            mapDoctorLocation.addAnnotation(annotation)
            
            let center = annotation.coordinate
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
            self.mapDoctorLocation.setRegion(region, animated: true)
        }
        
    }

}
