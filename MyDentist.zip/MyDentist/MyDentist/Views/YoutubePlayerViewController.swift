//
//  YoutubePlayerViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 02/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit
import youtube_ios_player_helper

class YoutubePlayerViewController: UIViewController
{
    
    @IBOutlet weak var vwYoutube: YTPlayerView!
    
    var strLinkToPlay: String = ""
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.vwYoutube.load(withVideoId: YouTubeHelper.getVideoIDFormYoutube(strLinkToPlay))
        self.vwYoutube.delegate = self
    }
    
    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
}

extension YoutubePlayerViewController: YTPlayerViewDelegate
{
    
    func playerViewDidBecomeReady(_ playerView: YTPlayerView)
    {
        
    }
    
    
    func playerView(_ playerView: YTPlayerView, receivedError error: YTPlayerError)
    {
        print(error)
    }
    
}
