//
//  ProfileViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 30/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController, UITextFieldDelegate
{
    
    @IBOutlet weak var svContent: UIScrollView!
    @IBOutlet weak var segmentUser: UISegmentedControl!
    
    @IBOutlet weak var txtFullName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtContactNo: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    
    var userID: String = ""
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.addDoneButtonOnKeyboard()
        txtAge.isHidden = true
        
        self.fillAllData()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        
        return true
    }
    
    override func viewDidLayoutSubviews()
    {
        svContent.contentSize = CGSize(width: 0, height: SCREEN_HEIGHT)
    }
    
    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnRegisterNowTapped(_ sender: Any)
    {
        let name: String = (txtFullName.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let add: String = (txtAddress.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let contact: String = (txtContactNo.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let age: String = (txtAge.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        
        if name == "" || add == "" || contact == "" {
            
            if segmentUser.selectedSegmentIndex == 1 {
                
                if age == "" {
                    
                    let alert = Utility.showAlertController(withTitle: "Required Field", withMessage: "All fields are requried for Updation.", isOkButton: true, isCancelButton: false)
                    self.present(alert, animated: true, completion: nil)
                    
                    return
                }
            } else {
                
                let alert = Utility.showAlertController(withTitle: "Required Field", withMessage: "All fields are requried for Updation.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
                
                return
            }
        }
        
        let objModel = UserModel()
        
        objModel.strID = userID
        objModel.strName = name
        objModel.strAddress = add
        objModel.strContact = contact
        objModel.strAge = age
        
        if segmentUser.selectedSegmentIndex == 0 {
            
            if DBManager.getInstance().updateDoctor(objModel: objModel) {
                
                _ = self.navigationController?.popViewController(animated: true)
            } else {
                
                let alert = Utility.showAlertController(withTitle: "Error", withMessage: "Something went Wrong. Please try again later.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
            }
        } else if segmentUser.selectedSegmentIndex == 1 {
            
            if DBManager.getInstance().updatePatient(objModel: objModel) {
                
                _ = self.navigationController?.popViewController(animated: true)
            } else {
                
                let alert = Utility.showAlertController(withTitle: "Error", withMessage: "Something went Wrong. Please try again later.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
            }
        } else if segmentUser.selectedSegmentIndex == 2 {
            
            if DBManager.getInstance().updateLab(objModel: objModel) {
                
                let alert = UIAlertController(title: "Success", message: "Your profile is updated.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    
                    _ = self.navigationController?.popViewController(animated: true)
                }))
                
                self.present(alert, animated: true, completion: nil)
            } else {
                
                let alert = Utility.showAlertController(withTitle: "Error", withMessage: "Something went Wrong. Please try again later.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    func addDoneButtonOnKeyboard()
    {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        doneToolbar.barStyle       = UIBarStyle.default
        let flexSpace              = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem  = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(RegisterViewController.doneButtonAction))
        
        var items = [UIBarButtonItem]()
        items.append(flexSpace)
        items.append(done)
        
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        
        self.txtAge.inputAccessoryView = doneToolbar
        self.txtContactNo.inputAccessoryView = doneToolbar
    }
    
    func doneButtonAction()
    {
        self.txtAge.resignFirstResponder()
        self.txtContactNo.resignFirstResponder()
    }
    
    func fillAllData()
    {
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            txtAge.isHidden = true
            segmentUser.selectedSegmentIndex = 0
            txtFullName.placeholder = "Enter Doctor name"
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            txtAge.isHidden = false
            segmentUser.selectedSegmentIndex = 1
            txtFullName.placeholder = "Enter Patient name"
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            txtAge.isHidden = true
            segmentUser.selectedSegmentIndex = 2
            txtFullName.placeholder = "Enter Lab name"
        }
        
        let objModel: UserModel = DBManager.getInstance().getUserDataByEmailAndPassword()
        
        txtFullName.text = objModel.strName
        txtEmail.text = objModel.strEmail
        txtPassword.text = objModel.strPassword
        txtAddress.text = objModel.strAddress
        txtContactNo.text = objModel.strContact
        txtAge.text = objModel.strAge
        
        userID = objModel.strID
    }
    
}
