//
//  DashboardViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 29/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit
import MessageUI

class DashboardViewController: UIViewController, MFMailComposeViewControllerDelegate
{

    @IBOutlet weak var btnBGMenu: UIButton!
    @IBOutlet weak var vwMenu: UIView!
    @IBOutlet weak var iv3Image: UIImageView!
    @IBOutlet weak var lbl3Name: UILabel!
    @IBOutlet weak var iv4Image: UIImageView!
    @IBOutlet weak var lbl4Name: UILabel!
    @IBOutlet weak var vw3: UIView!
    @IBOutlet weak var vw4: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        if !UserDefaults.standard.bool(forKey: "isLogin") {
            
            self.performSegue(withIdentifier: "openLogin", sender: nil)
        }
        
        let objGesture: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(self.handleGesture(sender:)))
        objGesture.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(objGesture)
        
        self.btnBGMenu.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        if UserDefaults.standard.bool(forKey: "isDoctor"){
            
            iv3Image.image = UIImage(named: "labbook.png")
            lbl3Name.text = "Laboratory"
            
            iv4Image.image = UIImage(named: "report.png")
            lbl4Name.text = "Reports"
            
            vw3.isHidden = false
            vw4.isHidden = false
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            iv3Image.image = UIImage(named: "patient.png")
            lbl3Name.text = "Treatments"
            
            iv4Image.image = UIImage(named: "findDoctor.png")
            lbl4Name.text = "Find Doctor"
            
            vw3.isHidden = false
            vw4.isHidden = false
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            vw3.isHidden = true
            
            iv3Image.image = UIImage(named: "labbook.png")
            lbl3Name.text = "Doctor Report"
            
            vw4.isHidden = true
        }
    }
    
    @IBAction func btnMenuTapped(_ sender: Any)
    {
        if vwMenu.frame.origin.x == -4 {
            UIView.animate(withDuration: 0.5, delay: 0, options: UIViewAnimationOptions.curveEaseOut, animations: { () -> Void in
                self.vwMenu.frame = CGRect(x: -500, y: 64, width: self.vwMenu.frame.size.width, height: self.vwMenu.frame.size.height)
            }, completion: { (isDone) in
                self.btnBGMenu.isHidden = true
            })
        } else {
            UIView.animate(withDuration: 0.5, delay: 0, options: UIViewAnimationOptions.curveEaseOut, animations: { () -> Void in
                self.vwMenu.frame = CGRect(x: -4, y: 64, width: self.vwMenu.frame.size.width, height: self.vwMenu.frame.size.height)
            }, completion: nil)
            
            self.btnBGMenu.isHidden = false
        }
    }
    
    @IBAction func btnBGMenuTapped(_ sender: Any)
    {
        UIView.animate(withDuration: 0.5, delay: 0, options: UIViewAnimationOptions.curveEaseOut, animations: { () -> Void in
            self.vwMenu.frame = CGRect(x: -500, y: 64, width: self.vwMenu.frame.size.width, height: self.vwMenu.frame.size.height)
        }, completion: { (isDone) in
            self.btnBGMenu.isHidden = true
        })
    }
    
    func handleGesture(sender: UISwipeGestureRecognizer)
    {
        UIView.animate(withDuration: 0.5, delay: 0, options: UIViewAnimationOptions.curveEaseOut, animations: { () -> Void in
            self.vwMenu.frame = CGRect(x: -300, y: 64, width: self.vwMenu.frame.size.width, height: self.vwMenu.frame.size.height)
        }, completion: nil)
        
        self.btnBGMenu.isHidden = true
    }
    
    @IBAction func btnProfileTapped(_ sender: Any)
    {
        self.performSegue(withIdentifier: "openProfile", sender: nil)
    }
    
    @IBAction func btnAppointmentsTapped(_ sender: Any)
    {
        if UserDefaults.standard.bool(forKey: "isPatient") {
            
            self.performSegue(withIdentifier: "openApointmentList", sender: nil)
        } else if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            self.performSegue(withIdentifier: "openDocAppointments", sender: nil)
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
//            self.performSegue(withIdentifier: "openReports", sender: nil)
            self.performSegue(withIdentifier: "openDocAppointments", sender: nil)
        }
    }
    
    @IBAction func btnTreatmentsTapped(_ sender: Any)
    {
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            self.performSegue(withIdentifier: "openFindDoctor", sender: nil)
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            self.performSegue(withIdentifier: "openTreatments", sender: nil)
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            self.performSegue(withIdentifier: "openReports", sender: nil)
        }
    }
    
    @IBAction func btnFindDoctorTapped(_ sender: Any)
    {
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            self.performSegue(withIdentifier: "openReports", sender: nil)
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            self.performSegue(withIdentifier: "openFindDoctor", sender: nil)
        }
    }
    
    @IBAction func btnRateUsTapped(_ sender: Any)
    {
        self.handleGesture(sender: UISwipeGestureRecognizer())
        
        UIApplication.shared.openURL(URL(string: APP_URL)!)
    }
    
    @IBAction func btnContactUsTapped(_ sender: Any)
    {
        self.handleGesture(sender: UISwipeGestureRecognizer())
        
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController
    {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients([EMAIL])
        
        mailComposerVC.setSubject("MyDentist App Contact")
        mailComposerVC.setMessageBody("\n\n\n\nUser ID : \(UserDefaults.standard.value(forKey: "UserID"))\nUser Email : \(UserDefaults.standard.value(forKey: "UserEmail")!)", isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert()
    {
        let alert = Utility.showAlertController(withTitle: "Could Not Send Email", withMessage: "Your device could not send an e-mail. Please check e-mail configuration settings and try again.", isOkButton: true, isCancelButton: false)
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        controller.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnLogoutTapped(_ sender: Any)
    {
        self.handleGesture(sender: UISwipeGestureRecognizer())
        
        UserDefaults.standard.set(false, forKey: "isLogin")
        UserDefaults.standard.set(false, forKey: "isDoctor")
        UserDefaults.standard.set(false, forKey: "isPatient")
        UserDefaults.standard.set(false, forKey: "isLab")
        
        UserDefaults.standard.set("", forKey: "UserEmail")
        UserDefaults.standard.set("", forKey: "UserPassword")
        UserDefaults.standard.set("", forKey: "UserID")
        
        self.performSegue(withIdentifier: "openLogin", sender: nil)
    }
    
}
