//
//  TreatmentsViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 01/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class TreatmentsViewController: UIViewController
{

    @IBOutlet weak var lblVid1Title: UILabel!
    @IBOutlet weak var lblVid2Title: UILabel!
    @IBOutlet weak var lblVid3Title: UILabel!
    @IBOutlet weak var lblVid4Title: UILabel!
    
    var selectedLink: String = ""
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        lblVid1Title.text = "10 Dental Care Tips\n(Watch Here)"
        lblVid2Title.text = "Dental care for Kids\n(Watch Here)"
        lblVid3Title.text = "Dental Plans\n(Watch Here)"
        lblVid4Title.text = "Dental Treatments\n(Watch Here)"
    }

    @IBAction func btnVid1Tapped(_ sender: Any)
    {
        selectedLink = "https://www.youtube.com/watch?v=A-Sj_vVn-EQ"
        self.performSegue(withIdentifier: "openVideoPlayer", sender: nil)
    }
    
    @IBAction func btnVid2Tapped(_ sender: Any)
    {
        selectedLink = "https://youtu.be/MBg3peXco-I"
        self.performSegue(withIdentifier: "openVideoPlayer", sender: nil)
    }
    
    @IBAction func btnVid3Tapped(_ sender: Any)
    {
        selectedLink = "https://www.youtube.com/watch?v=hfhFopDMntg"
        self.performSegue(withIdentifier: "openVideoPlayer", sender: nil)
    }
    
    @IBAction func btnVid4Tapped(_ sender: Any)
    {
        selectedLink = "https://www.youtube.com/watch?v=OR6uDvdcxjo"
        self.performSegue(withIdentifier: "openVideoPlayer", sender: nil)
    }
    
    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "openVideoPlayer" {
            
            let objView: YoutubePlayerViewController = segue.destination as! YoutubePlayerViewController
            
            objView.strLinkToPlay = selectedLink
        }
    }
    
}
