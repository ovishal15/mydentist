//
//  FindDoctorListViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 31/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class FindDoctorListViewController: UIViewController
{  
    var marrData: NSMutableArray = NSMutableArray()
    var selectedDoctor: Int = 0
    
    @IBOutlet weak var tblData: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        tblData.tableFooterView = UIView()
        self.fetchDataFromDB()
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            self.navigationItem.title = "Labs"
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            self.navigationItem.title = "Doctors"
        }
    }
    
    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    func fetchDataFromDB()
    {
        marrData = NSMutableArray()
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            marrData = DBManager.getInstance().selectAllLab()
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            marrData = DBManager.getInstance().selectAllDoctor()
        }
        
        
        if marrData.count > 0 {
            
            tblData.reloadData()
            tblData.isHidden = false
        } else {
            
            tblData.isHidden = true
        }
    }
    
}

extension FindDoctorListViewController: UITableViewDelegate, UITableViewDataSource
{
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return marrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell: FindDoctorTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FindDoctorTableViewCell
        
        let objModel: UserModel = self.marrData[indexPath.row] as! UserModel
        
        cell.lblName.text = objModel.strName
        cell.lblContactNo.text = objModel.strContact
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            cell.ivIcon.image = UIImage(named: "iconLab.jpg")
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            cell.ivIcon.image = UIImage(named: "iconDoc.png")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        
        selectedDoctor = indexPath.row
        
        self.performSegue(withIdentifier: "openDetail", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "openDetail" {
            
            let objViewController: DocDetailViewController = segue.destination as! DocDetailViewController
            objViewController.objUserModel = self.marrData[selectedDoctor] as! UserModel
        }
    }
    
}
