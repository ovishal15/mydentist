//
//  DocAppointmentsViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 01/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class DocAppointmentsViewController: UIViewController
{
    
    var marrWaitingData: NSMutableArray = NSMutableArray()
    var marrRejectedData: NSMutableArray = NSMutableArray()
    var marrAcceptedData: NSMutableArray = NSMutableArray()
    
    @IBOutlet weak var tblWaitingData: UITableView!
    @IBOutlet weak var tblRejectedData: UITableView!
    @IBOutlet weak var tblAcceptedData: UITableView!
    
    @IBOutlet weak var segmentData: UISegmentedControl!
    @IBOutlet weak var lblNoData: UILabel!
    @IBOutlet weak var vwInfo: UIView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblExtraInfo: UILabel!
    @IBOutlet weak var lblProblem: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblPatientName: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    
    @IBOutlet weak var btnReClose: UIButton!
    @IBOutlet weak var btnClose: UIButton!
    @IBOutlet weak var btnReshedule: UIButton!
    
    @IBOutlet weak var vwDateTimeView: UIView!
    @IBOutlet weak var vwBG: UIView!
    @IBOutlet weak var datepickerBook: UIDatePicker!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        tblWaitingData.tableFooterView = UIView()
        tblAcceptedData.tableFooterView = UIView()
        tblRejectedData.tableFooterView = UIView()
        
        self.fetchDataFromDBForWaitingStatus()
        
        self.tblAcceptedData.isHidden = true
        self.tblRejectedData.isHidden = true
        
        btnReClose.isHidden = false
        btnReshedule.isHidden = false
        btnClose.isHidden = true
        
        vwInfo.isHidden = true
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            self.lblNoData.text = "No any appointments are Available!"
            self.navigationItem.title = "Appointments"
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            self.lblNoData.text = "No any reports are Available!"
            self.navigationItem.title = "Reports"
        }
    }

    @IBAction func handleSegmentChanged(_ sender: Any)
    {
        if segmentData.selectedSegmentIndex == 0 {
            
            self.fetchDataFromDBForWaitingStatus()
            
            self.tblAcceptedData.isHidden = true
            self.tblRejectedData.isHidden = true
            
            btnReClose.isHidden = false
            btnReshedule.isHidden = false
            btnClose.isHidden = true
        } else if segmentData.selectedSegmentIndex == 1 {
            
            self.fetchDataFromDBForAcceptedStatus()
            
            self.tblWaitingData.isHidden = true
            self.tblRejectedData.isHidden = true
            
            btnReClose.isHidden = true
            btnReshedule.isHidden = true
            btnClose.isHidden = false
        } else if segmentData.selectedSegmentIndex == 2 {
            
            self.fetchDataFromDBForRejectedStatus()
            
            self.tblWaitingData.isHidden = true
            self.tblAcceptedData.isHidden = true
            
            btnReClose.isHidden = true
            btnReshedule.isHidden = true
            btnClose.isHidden = false
        }
    }
    
    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }

    @IBAction func btnAcceptTapped(_ sender: Any)
    {
        let btnTag: Int = (sender as! UIButton).tag
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            let objModel: AppointmentModel = self.marrWaitingData[btnTag] as! AppointmentModel
            
            if DBManager.getInstance().updateStatusOfAppointment(strID: objModel.strID, withStatus: "Accepted") {
                
                let alert = UIAlertController(title: "Success", message: "You have successfully accepted this appointments.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    
                    self.fetchDataFromDBForWaitingStatus()
                    self.tblWaitingData.reloadData()
                }))
                
                self.present(alert, animated: true, completion: nil)
            }
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            let objModel: ReportModel = self.marrWaitingData[btnTag] as! ReportModel
            
            if DBManager.getInstance().updateStatusOfReportAccept(strID: objModel.strID, withStatus: "Accepted") {
                
                let alert = UIAlertController(title: "Success", message: "You have successfully accepted this booking.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    
                    self.fetchDataFromDBForWaitingStatus()
                    self.tblWaitingData.reloadData()
                }))
                
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func btnRejectedTapped(_ sender: Any)
    {
        let btnTag: Int = (sender as! UIButton).tag
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            let objModel: AppointmentModel = self.marrWaitingData[btnTag] as! AppointmentModel
            
            if DBManager.getInstance().updateStatusOfAppointment(strID: objModel.strID, withStatus: "Rejected") {
                
                let alert = UIAlertController(title: "Success", message: "You have successfully rejected this appointments.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    
                    self.fetchDataFromDBForWaitingStatus()
                    self.tblWaitingData.reloadData()
                }))
                
                self.present(alert, animated: true, completion: nil)
            }
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            let objModel: ReportModel = self.marrWaitingData[btnTag] as! ReportModel
            
            if DBManager.getInstance().updateStatusOfReportAccept(strID: objModel.strID, withStatus: "Rejected") {
                
                let alert = UIAlertController(title: "Success", message: "You have successfully rejected this booking.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    
                    self.fetchDataFromDBForWaitingStatus()
                    self.tblWaitingData.reloadData()
                }))
                
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func fetchDataFromDBForWaitingStatus()
    {
        marrWaitingData = NSMutableArray()
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
             marrWaitingData = DBManager.getInstance().selectAllAppointmentListByStatus(withStatus: "Waiting")
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
             marrWaitingData = DBManager.getInstance().selectAllReportListByStatus(withStatus: "Waiting")
        }
        
        if marrWaitingData.count > 0 {
            
            tblWaitingData.reloadData()
            tblWaitingData.isHidden = false
        } else {
            
            tblWaitingData.isHidden = true
        }
    }
    
    func fetchDataFromDBForAcceptedStatus()
    {
         marrAcceptedData = NSMutableArray()
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            marrAcceptedData = DBManager.getInstance().selectAllAppointmentListByStatus(withStatus: "Accepted")
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            marrAcceptedData = DBManager.getInstance().selectAllReportListByStatus(withStatus: "Accepted")
        }
        
        if marrAcceptedData.count > 0 {
            
            tblAcceptedData.reloadData()
            tblAcceptedData.isHidden = false
        } else {
            
            tblAcceptedData.isHidden = true
        }
    }
    
    func fetchDataFromDBForRejectedStatus()
    {
        marrRejectedData = NSMutableArray()
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            marrRejectedData = DBManager.getInstance().selectAllAppointmentListByStatus(withStatus: "Rejected")
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            marrRejectedData = DBManager.getInstance().selectAllReportListByStatus(withStatus: "Rejected")
        }
        
        if marrRejectedData.count > 0 {
            
            tblRejectedData.reloadData()
            tblRejectedData.isHidden = false
        } else {
            
            tblRejectedData.isHidden = true
        }
    }
    
    @IBAction func btnCloseInfoTapped(_ sender: Any)
    {
        vwInfo.isHidden = true
    }
    
    @IBAction func btnResheduleTapped(_ sender: Any)
    {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.vwInfo.frame.size.height - self.vwDateTimeView.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.vwInfo.frame.size.height - self.vwDateTimeView.frame.size.height
            self.vwBG.isHidden = false
        }
    }
    
    @IBAction func btnReCloseTapped(_ sender: Any)
    {
        vwInfo.isHidden = true
    }
    
    @IBAction func btnCancelPickerTapped(_ sender: Any)
    {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.vwInfo.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.vwInfo.frame.size.height
            self.vwBG.isHidden = true
        }
    }
    
    @IBAction func btnDonePickerTapped(_ sender: Any)
    {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseIn, animations: {
            
            self.vwDateTimeView.frame.origin.y = self.vwInfo.frame.size.height
        }) { (isAnimated) in
            
            self.vwDateTimeView.frame.origin.y = self.vwInfo.frame.size.height
            self.vwBG.isHidden = true
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy hh:mm:ss"
        let selectedDate = dateFormatter.string(from: datepickerBook.date)
        
        lblDate.text = selectedDate
        let vwTag: String = vwInfo.accessibilityHint!
        
        if DBManager.getInstance().updateDateOfAppointmnetWithID(strID: vwTag, withDate: selectedDate) {
            
            let alert = UIAlertController(title: "Success", message: "This appointment Reschedule successfully.", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                
                self.fetchDataFromDBForWaitingStatus()
            }))
            
            self.present(alert, animated: true, completion: nil)
        }
        
    }

}

extension DocAppointmentsViewController: UITableViewDelegate, UITableViewDataSource
{
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView == tblWaitingData {
            
            return marrWaitingData.count
        } else if tableView == tblAcceptedData {
            
            return marrAcceptedData.count
        } else if tableView == tblRejectedData {
            
            return marrRejectedData.count
        } else {
            
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell: AppointmentTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AppointmentTableViewCell
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            var objModel: AppointmentModel!
            
            if tableView == tblWaitingData {
                
                objModel = self.marrWaitingData[indexPath.row] as! AppointmentModel
                
                cell.btnReject.tag = indexPath.row
                cell.btnAccept.tag = indexPath.row
            } else if tableView == tblAcceptedData {
                
                objModel = self.marrAcceptedData[indexPath.row] as! AppointmentModel
            } else {
                
                objModel = self.marrRejectedData[indexPath.row] as! AppointmentModel
            }
            
            cell.ivLogo.image = UIImage(named: "logoAppoint.png")
            
            cell.lblName.text = objModel.strName
            cell.lblDate.text = objModel.strDate
            
            let objPatientModel: UserModel = DBManager.getInstance().getPatientByPatientID(strID: objModel.strPatientID)
            
            cell.lblPatientName.text = "Patient Name : \(objPatientModel.strName)"
            cell.lblPatientContactNo.text = "Patient Contact : \(objPatientModel.strContact)"
            
        } else if UserDefaults.standard.bool(forKey: "isLab") {
            
            var objModel: ReportModel!
            
            if tableView == tblWaitingData {
                
                objModel = self.marrWaitingData[indexPath.row] as! ReportModel
                
                cell.btnReject.tag = indexPath.row
                cell.btnAccept.tag = indexPath.row
            } else if tableView == tblAcceptedData {
                
                objModel = self.marrAcceptedData[indexPath.row] as! ReportModel
            } else {
                
                objModel = self.marrRejectedData[indexPath.row] as! ReportModel
            }
            
            cell.ivLogo.image = UIImage(named: "iconRepo.png")
//            let objDocModel: UserModel = DBManager.getInstance().getDoctorByDoctorID(strID: objModel.strDoctorID)
            
//            let objLabModel: UserModel = DBManager.getInstance().getLabUserByLabID(strID: objModel.strLabID)
            
            cell.lblName.text = objModel.strName
            cell.lblDate.text = objModel.strDate
            
            cell.lblPatientName.text = "Work Type : \(objModel.strWorkType)"
            cell.lblPatientContactNo.text = "isUrgent : \(objModel.strIsUrgent)"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if UserDefaults.standard.bool(forKey: "isLab") {
            
            return
        }
        
        var objModel: AppointmentModel!
        
        if tableView == tblWaitingData {
            
            objModel = self.marrWaitingData[indexPath.row] as! AppointmentModel
        } else if tableView == tblAcceptedData {
            
            objModel = self.marrAcceptedData[indexPath.row] as! AppointmentModel
        } else {
            
            objModel = self.marrRejectedData[indexPath.row] as! AppointmentModel
        }
        
        let objPatientModel: UserModel = DBManager.getInstance().getPatientByPatientID(strID: objModel.strPatientID)
        
        lblPatientName.text = objPatientModel.strName
        lblTitle.text = objModel.strName
        lblProblem.text = objModel.strProblem
        lblExtraInfo.text = objModel.strNote
        lblDate.text = objModel.strDate
        lblStatus.text = objModel.strStatus
        
        if objModel.strStatus == "Waiting" {
            
            lblStatus.textColor = UIColor.blue
        } else if objModel.strStatus == "Rejected" {
            
            lblStatus.textColor = UIColor.red
        } else if objModel.strStatus == "Accepted" {
            
            lblStatus.textColor = UIColor.green
        }
        
        vwInfo.accessibilityHint = objModel.strID
        vwInfo.isHidden = false
    }
    
}

