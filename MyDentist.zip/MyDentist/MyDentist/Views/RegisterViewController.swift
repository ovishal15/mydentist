//
//  RegisterViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 29/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController, UITextFieldDelegate
{

    @IBOutlet weak var svContent: UIScrollView!
    @IBOutlet weak var segmentUser: UISegmentedControl!
    
    @IBOutlet weak var txtFullName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtContactNo: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.addDoneButtonOnKeyboard()
        txtAge.isHidden = true
        txtFullName.placeholder = "Enter Doctor name"
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        
        return true
    }
    
    override func viewDidLayoutSubviews()
    {
        svContent.contentSize = CGSize(width: 0, height: SCREEN_HEIGHT)
    }

    @IBAction func btnBackTapped(_ sender: Any)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnRegisterNowTapped(_ sender: Any)
    {
        let name: String = (txtFullName.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let email: String = (txtEmail.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let pwd: String = (txtPassword.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let cpwd: String = (txtConfirmPassword.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let add: String = (txtAddress.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let contact: String = (txtContactNo.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let age: String = (txtAge.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        
        if name == "" || email == "" || pwd == "" || cpwd == "" || add == "" || contact == "" {
            
            if segmentUser.selectedSegmentIndex == 1 {
                
                if age == "" {
                    
                    let alert = Utility.showAlertController(withTitle: "Required Field", withMessage: "All fields are requried for Registration.", isOkButton: true, isCancelButton: false)
                    self.present(alert, animated: true, completion: nil)
                    
                    return
                }
            } else {
               
                let alert = Utility.showAlertController(withTitle: "Required Field", withMessage: "All fields are requried for Registration.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
                
                return
            }
        }
        
        if !Utility.validateEmail(email) {
            
            let alert = Utility.showAlertController(withTitle: "Invalid Email", withMessage: "Please enter valid email address.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
            
            return
        }
        
        if pwd != cpwd {
            
            let alert = Utility.showAlertController(withTitle: "Must Same", withMessage: "Password & Confirm Password must be Same for Verfications.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
            
            return
        }
        
        if !DBManager.getInstance().isEmailAddressAvailable(email: email) {
            
            let alert = Utility.showAlertController(withTitle: "Already Exists", withMessage: "This email address is already exists. Please choose another email.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
            
            return
        }
        
        let objModel = UserModel()
        
        objModel.strName = name
        objModel.strEmail = email
        objModel.strPassword = pwd
        objModel.strAddress = add
        objModel.strContact = contact
        objModel.strAge = age
        objModel.strLat = "23.0225"
        objModel.strLog = "72.5714"
        
        if segmentUser.selectedSegmentIndex == 0 {
            
            if DBManager.getInstance().insertDoctor(objModel: objModel) {
                
                let alert = UIAlertController(title: "Success", message: "Your registration to this app is Completed. Please login with your credentials.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    
                    self.dismiss(animated: true, completion: nil)
                }))
                
                self.present(alert, animated: true, completion: nil)
            } else {
                
                let alert = Utility.showAlertController(withTitle: "Error", withMessage: "Something went Wrong. Please try again later.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
            }
        } else if segmentUser.selectedSegmentIndex == 1 {
            
            if DBManager.getInstance().insertPatient(objModel: objModel) {
                
                let alert = UIAlertController(title: "Success", message: "Your registration to this app is Completed. Please login with your credentials.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    
                    self.dismiss(animated: true, completion: nil)
                }))
                
                self.present(alert, animated: true, completion: nil)
            } else {
                
                let alert = Utility.showAlertController(withTitle: "Error", withMessage: "Something went Wrong. Please try again later.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
            }
        } else if segmentUser.selectedSegmentIndex == 2 {
            
            if DBManager.getInstance().insertLab(objModel: objModel) {
                
                let alert = UIAlertController(title: "Success", message: "Your registration to this app is Completed. Please login with your credentials.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    
                    self.dismiss(animated: true, completion: nil)
                }))
                
                self.present(alert, animated: true, completion: nil)
            } else {
                
                let alert = Utility.showAlertController(withTitle: "Error", withMessage: "Something went Wrong. Please try again later.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
            }
        }

    }
    
    @IBAction func handleSegmentUserChanged(_ sender: Any)
    {
        if segmentUser.selectedSegmentIndex == 1 {
            
            txtAge.isHidden = false
        } else {
            
            txtAge.isHidden = true
        }
        
        if segmentUser.selectedSegmentIndex == 0 {
            
            txtFullName.placeholder = "Enter Doctor name"
        } else if segmentUser.selectedSegmentIndex == 1 {
            
            txtFullName.placeholder = "Enter Patient name"
        } else if segmentUser.selectedSegmentIndex == 1 {
            
            txtFullName.placeholder = "Enter Lab name"
        }
    }
    
    func addDoneButtonOnKeyboard()
    {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        doneToolbar.barStyle       = UIBarStyle.default
        let flexSpace              = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem  = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(RegisterViewController.doneButtonAction))
        
        var items = [UIBarButtonItem]()
        items.append(flexSpace)
        items.append(done)
        
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        
        self.txtAge.inputAccessoryView = doneToolbar
        self.txtContactNo.inputAccessoryView = doneToolbar
    }
    
    func doneButtonAction()
    {
        self.txtAge.resignFirstResponder()
        self.txtContactNo.resignFirstResponder()
    }
    
}
