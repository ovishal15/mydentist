//
//  LoginViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 29/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate
{

    @IBOutlet weak var segmentUser: UISegmentedControl!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        
        return true
    }
    
    @IBAction func btnLoginNowTapped(_ sender: Any)
    {
        let email: String = (txtEmail.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        let pwd: String = (txtPassword.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
        
        if email == "" || pwd == "" {
            
            let alert = Utility.showAlertController(withTitle: "Required Field", withMessage: "Email & Password both field requried for Login.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
            
            return
        }
        
        if !Utility.validateEmail(email) {
            
            let alert = Utility.showAlertController(withTitle: "Invalid Email", withMessage: "Please enter valid email address.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
            
            return
        }
        
        let responseFormDB = DBManager.getInstance().isUserLoginSuccessful(withEmail: email, withPassword: pwd, withType: segmentUser.selectedSegmentIndex)
        
        if responseFormDB.0 {
            
            if segmentUser.selectedSegmentIndex == 0 {
                
                UserDefaults.standard.set(true, forKey: "isDoctor")
                UserDefaults.standard.set(false, forKey: "isPatient")
                UserDefaults.standard.set(false, forKey: "isLab")
            } else if segmentUser.selectedSegmentIndex == 1 {
                
                UserDefaults.standard.set(false, forKey: "isDoctor")
                UserDefaults.standard.set(true, forKey: "isPatient")
                UserDefaults.standard.set(false, forKey: "isLab")
            } else if segmentUser.selectedSegmentIndex == 2 {
                
                UserDefaults.standard.set(false, forKey: "isDoctor")
                UserDefaults.standard.set(false, forKey: "isPatient")
                UserDefaults.standard.set(true, forKey: "isLab")
            }
            
            UserDefaults.standard.set(email, forKey: "UserEmail")
            UserDefaults.standard.set(pwd, forKey: "UserPassword")
            UserDefaults.standard.set(responseFormDB.1, forKey: "UserID")
            
            UserDefaults.standard.set(true, forKey: "isLogin")
            UserDefaults.standard.synchronize()
            
            self.dismiss(animated: true, completion: nil)
        } else {
            
            let alert = Utility.showAlertController(withTitle: "Error", withMessage: "Your credentials not found. Please check your email & password.", isOkButton: true, isCancelButton: false)
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
}
