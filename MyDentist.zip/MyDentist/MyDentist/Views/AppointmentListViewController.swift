//
//  AppointmentListViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 30/03/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class AppointmentListViewController: UIViewController
{

    var marrData: NSMutableArray = NSMutableArray()
    
    @IBOutlet weak var btnClose: UIButton!
    @IBOutlet weak var lblLabContact: UILabel!
    @IBOutlet weak var lblLabEmail: UILabel!
    @IBOutlet weak var lblLabAppointmentDate: UILabel!
    @IBOutlet weak var lblLabStatus: UILabel!
    @IBOutlet weak var lblLabName: UILabel!
    @IBOutlet weak var vwInfo: UIView!
    @IBOutlet weak var vwLabInfo: UIView!
    @IBOutlet weak var tblData: UITableView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblExtraInfo: UILabel!
    @IBOutlet weak var lblProblem: UILabel!
    @IBOutlet weak var lblDocName: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblNoData: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        self.fetchDataFromDB()
        tblData.tableFooterView = UIView()
        vwInfo.isHidden = true
        vwLabInfo.isHidden = true
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            self.navigationItem.title = "Lab Booking"
            lblNoData.text = "No any Labs are Available!"
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            self.navigationItem.title = "Appointments"
            lblNoData.text = "No any Appoiments are Available!"
        }
    }
    
    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    func fetchDataFromDB()
    {
        marrData = NSMutableArray()
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            marrData = DBManager.getInstance().selectAllLabBookingByUser()
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            marrData = DBManager.getInstance().selectAllAppointmentByUser()
        }
        
        if marrData.count > 0 {
            
            tblData.reloadData()
            tblData.isHidden = false
        } else {
            
            tblData.isHidden = true
        }
    }

    @IBAction func btnCloseInfoTapped(_ sender: Any)
    {
        vwInfo.isHidden = true
    }
    
    @IBAction func bntLabCloseInfoTapped(_ sender: Any)
    {
        vwLabInfo.isHidden = true
    }
    
}

extension AppointmentListViewController: UITableViewDelegate, UITableViewDataSource
{
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return marrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell: AppointmentTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AppointmentTableViewCell
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            let objModel: LabBookModel = self.marrData[indexPath.row] as! LabBookModel
            
            cell.lblName.text = objModel.strDate
            cell.lblStaus.text = "Status : \(objModel.strStatus)"
            
            if objModel.strStatus == "Waiting" {
                
                cell.lblStaus.textColor = UIColor.blue
            } else if objModel.strStatus == "Rejected" {
                
                cell.lblStaus.textColor = UIColor.red
            } else if objModel.strStatus == "Accepted" {
                
                cell.lblStaus.textColor = UIColor.green
            }
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            let objModel: AppointmentModel = self.marrData[indexPath.row] as! AppointmentModel
            
            cell.lblName.text = objModel.strName
            cell.lblStaus.text = "Status : \(objModel.strStatus)"
            
            if objModel.strStatus == "Waiting" {
                
                cell.lblStaus.textColor = UIColor.blue
            } else if objModel.strStatus == "Rejected" {
                
                cell.lblStaus.textColor = UIColor.red
            } else if objModel.strStatus == "Accepted" {
                
                cell.lblStaus.textColor = UIColor.green
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if UserDefaults.standard.bool(forKey: "isDoctor") {
            
            let objModel: LabBookModel = self.marrData[indexPath.row] as! LabBookModel
            
            let objLabModel: UserModel = DBManager.getInstance().getLabUserByLabID(strID: objModel.strLabID)
            
            lblLabName.text = objLabModel.strName
            lblLabContact.text = objLabModel.strContact
            lblLabEmail.text = objLabModel.strEmail
            lblLabAppointmentDate.text = objModel.strDate
            lblLabStatus.text = objModel.strStatus
            
            if objModel.strStatus == "Waiting" {
                
                lblLabStatus.textColor = UIColor.blue
            } else if objModel.strStatus == "Cancelled" {
                
                lblLabStatus.textColor = UIColor.red
            } else if objModel.strStatus == "Accepted" {
                
                lblLabStatus.textColor = UIColor.green
            }
            
            vwLabInfo.isHidden = false
        } else if UserDefaults.standard.bool(forKey: "isPatient") {
            
            let objModel: AppointmentModel = self.marrData[indexPath.row] as! AppointmentModel
            
            let objDocModel: UserModel = DBManager.getInstance().getDoctorByDoctorID(strID: objModel.strDoctorID)
            
            lblDocName.text = objDocModel.strName
            lblTitle.text = objModel.strName
            lblProblem.text = objModel.strProblem
            lblExtraInfo.text = objModel.strNote
            lblDate.text = objModel.strDate
            lblStatus.text = objModel.strStatus
            
            if objModel.strStatus == "Waiting" {
                
                lblStatus.textColor = UIColor.blue
            } else if objModel.strStatus == "Cancelled" {
                
                lblStatus.textColor = UIColor.red
            } else if objModel.strStatus == "Accepted" {
                
                lblStatus.textColor = UIColor.green
            }
            
            vwInfo.isHidden = false
        }
        
    }
    
}

