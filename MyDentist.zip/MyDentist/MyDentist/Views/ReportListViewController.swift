//
//  ReportListViewController.swift
//  MyDentist
//
//  Created by Hardik Trivedi on 03/04/2017.
//  Copyright © 2017 The iHart Firm. All rights reserved.
//

import UIKit

class ReportListViewController: UIViewController
{

    var marrData: NSMutableArray = NSMutableArray()
    
    @IBOutlet weak var tblData: UITableView!
    @IBOutlet weak var lblLabname: UILabel!
    @IBOutlet weak var lblContactName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblDeliveryDate: UILabel!
    @IBOutlet weak var lblWorkType: UILabel!
    @IBOutlet weak var lblIsTrial: UILabel!
    @IBOutlet weak var lblIsUrgent: UILabel!
    @IBOutlet weak var vwInfo: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        tblData.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        vwInfo.isHidden = true
        self.fetchDataFromDB()
        
        if UserDefaults.standard.bool(forKey: "isLab") {
            
            self.navigationItem.rightBarButtonItem = nil
        } else {
            
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(named: "addData"), style: .plain, target: self, action: #selector(self.btnAddDataTapped(_:)))
        }
    }
    
    @IBAction func btnBackTapped(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    func fetchDataFromDB()
    {
        marrData = NSMutableArray()
        
        marrData = DBManager.getInstance().selectAllReport()
        
        if marrData.count > 0 {
            
            tblData.reloadData()
            tblData.isHidden = false
        } else {
            
            tblData.isHidden = true
        }
    }
    
    @IBAction func btnAddDataTapped(_ sender: Any)
    {
        self.performSegue(withIdentifier: "openDetail", sender: nil)
    }
    
    @IBAction func btnCloseInfoTapped(_ sender: Any)
    {
        vwInfo.isHidden = true
    }
}

extension ReportListViewController: UITableViewDelegate, UITableViewDataSource
{
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return marrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell: FindDoctorTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FindDoctorTableViewCell
        
        let objModel: ReportModel = self.marrData[indexPath.row] as! ReportModel
        
        cell.lblName.text = objModel.strName
        cell.lblContactNo.text = "Delivery Date : \(objModel.strDate)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let objModel: ReportModel = self.marrData[indexPath.row] as! ReportModel
        
        lblEmail.text = objModel.strStatus
        
        if objModel.strStatus == "Waiting" {
            
            lblEmail.textColor = UIColor.blue
        } else if objModel.strStatus == "Rejected" {
            
            lblEmail.textColor = UIColor.red
        } else if objModel.strStatus == "Accepted" {
            
            lblEmail.textColor = UIColor.green
        }
        
        let objLabModel: UserModel = DBManager.getInstance().getLabUserByLabID(strID: objModel.strLabID)
        
        lblLabname.text = objLabModel.strName
        lblContactName.text = objLabModel.strContact
        lblDeliveryDate.text = objModel.strDate
        lblWorkType.text = objModel.strWorkType
        lblIsTrial.text = objModel.strIsTrial
        lblIsUrgent.text = objModel.strIsUrgent
        
        vwInfo.isHidden = false
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete {
            
            let objModel: ReportModel = self.marrData[indexPath.row] as! ReportModel
            
            if DBManager.getInstance().deleteReport(objModel: objModel) {
                
                self.fetchDataFromDB()
                
                let alert = Utility.showAlertController(withTitle: "Success", withMessage: "Delete successfully.", isOkButton: true, isCancelButton: false)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
}
